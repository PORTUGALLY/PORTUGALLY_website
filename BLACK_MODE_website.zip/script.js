document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const phone = "201130258987";
  document.querySelectorAll(".order-button").forEach((button) => {
    button.addEventListener("click", () => {
      const product = button.dataset.product || "العطر";
      const message = `أهلاً، عايز أستفسر عن سعر ${product} من BLACK MODE`;
      window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
    });
  });
});
